import { Hero } from '@/app/components/Hero';
import { Services } from '@/app/components/Services';
import { Features } from '@/app/components/Features';
import { Stats } from '@/app/components/Stats';
import { CTA } from '@/app/components/CTA';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-900">
      <Hero />
      <Services />
      <Features />
      <Stats />
      <CTA />
    </div>
  );
}
