import { motion } from 'motion/react';
import { AnimatedShape } from './AnimatedShape';
import { Shield, Rocket, Users, BarChart } from 'lucide-react';

const features = [
  {
    icon: Shield,
    title: 'Secure & Reliable',
    description: 'Enterprise-grade security with 99.9% uptime guarantee',
  },
  {
    icon: Rocket,
    title: 'Fast Delivery',
    description: 'Agile development process with quick turnaround times',
  },
  {
    icon: Users,
    title: 'Expert Team',
    description: 'Experienced professionals dedicated to your success',
  },
  {
    icon: BarChart,
    title: 'Data Driven',
    description: 'Analytics and insights to optimize performance',
  },
];

export function Features() {
  return (
    <section className="relative py-32 bg-slate-800 overflow-hidden">
      {/* Animated Shapes */}
      <AnimatedShape
        type="cube"
        color="#3b82f6"
        size={150}
        position={{ x: '5%', y: '30%' }}
        delay={0}
      />
      <AnimatedShape
        type="sphere"
        color="#a855f7"
        size={120}
        position={{ x: '90%', y: '60%' }}
        delay={0.5}
      />

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left: Content */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <h2 className="text-5xl md:text-6xl text-white mb-6">
              Why Choose{' '}
              <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
                Techcognize
              </span>
            </h2>
            <p className="text-xl text-white/70 mb-12">
              We combine innovation with expertise to deliver exceptional results that drive
              your business forward
            </p>

            <div className="space-y-6">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, x: -30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="flex items-start gap-4 group cursor-pointer"
                >
                  <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 p-3 group-hover:scale-110 transition-transform duration-300">
                    <feature.icon className="w-full h-full text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl text-white mb-2 group-hover:text-blue-400 transition-colors">
                      {feature.title}
                    </h3>
                    <p className="text-white/60">{feature.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right: Floating 3D Visual */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative h-[600px] hidden lg:block"
          >
            <div className="absolute inset-0 flex items-center justify-center">
              <motion.div
                animate={{
                  rotateY: [0, 360],
                }}
                transition={{
                  duration: 20,
                  repeat: Infinity,
                  ease: 'linear',
                }}
                style={{ transformStyle: 'preserve-3d' }}
                className="relative w-80 h-80"
              >
                {/* Central Sphere */}
                <motion.div
                  animate={{ y: [-20, 20, -20] }}
                  transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-48 h-48 rounded-full bg-gradient-to-br from-blue-400 to-purple-600 shadow-2xl shadow-purple-500/50"
                  style={{
                    boxShadow: '0 0 80px rgba(168, 85, 247, 0.6), inset 0 0 60px rgba(255, 255, 255, 0.2)',
                  }}
                />

                {/* Orbiting Elements */}
                {[0, 1, 2, 3].map((i) => (
                  <motion.div
                    key={i}
                    animate={{ rotate: 360 }}
                    transition={{
                      duration: 10 + i * 2,
                      repeat: Infinity,
                      ease: 'linear',
                    }}
                    className="absolute top-1/2 left-1/2 w-full h-full"
                    style={{
                      transformOrigin: 'center',
                      transform: `rotate(${i * 90}deg)`,
                    }}
                  >
                    <div
                      className="absolute top-0 left-1/2 -translate-x-1/2 w-12 h-12 rounded-lg bg-gradient-to-br from-cyan-400 to-blue-600 shadow-lg"
                      style={{
                        boxShadow: '0 0 30px rgba(34, 211, 238, 0.6)',
                      }}
                    />
                  </motion.div>
                ))}
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
