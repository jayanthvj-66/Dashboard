import { motion } from 'motion/react';
import { FloatingCard } from './FloatingCard';
import { Code, Smartphone, Cloud, Zap, Cpu, Layers } from 'lucide-react';

const services = [
  {
    icon: Code,
    title: 'Web Development',
    description: 'Custom web applications built with modern frameworks and best practices',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    icon: Smartphone,
    title: 'Mobile Apps',
    description: 'Native and cross-platform mobile solutions for iOS and Android',
    color: 'from-purple-500 to-pink-500',
  },
  {
    icon: Cloud,
    title: 'Cloud Solutions',
    description: 'Scalable cloud infrastructure and deployment strategies',
    color: 'from-green-500 to-emerald-500',
  },
  {
    icon: Zap,
    title: 'Performance',
    description: 'Lightning-fast applications optimized for speed and efficiency',
    color: 'from-yellow-500 to-orange-500',
  },
  {
    icon: Cpu,
    title: 'AI Integration',
    description: 'Intelligent features powered by machine learning and AI',
    color: 'from-indigo-500 to-purple-500',
  },
  {
    icon: Layers,
    title: 'UI/UX Design',
    description: 'Beautiful, intuitive interfaces that users love',
    color: 'from-pink-500 to-rose-500',
  },
];

export function Services() {
  return (
    <section className="relative py-32 bg-gradient-to-b from-slate-900 to-slate-800 overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-10 w-72 h-72 bg-blue-500 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-500 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-20"
        >
          <h2 className="text-5xl md:text-6xl text-white mb-6">
            Our <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">Services</span>
          </h2>
          <p className="text-xl text-white/70 max-w-2xl mx-auto">
            Comprehensive solutions tailored to your business needs
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <FloatingCard key={service.title} delay={index * 0.1}>
              <div className="relative">
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${service.color} p-4 mb-6 shadow-lg`}>
                  <service.icon className="w-full h-full text-white" />
                </div>
                <h3 className="text-2xl text-white mb-4">{service.title}</h3>
                <p className="text-white/70 leading-relaxed">{service.description}</p>
              </div>
            </FloatingCard>
          ))}
        </div>
      </div>
    </section>
  );
}
