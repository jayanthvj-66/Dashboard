import { motion, useMotionValue, useTransform, animate } from 'motion/react';
import { useEffect, useRef } from 'react';

interface StatItemProps {
  value: number;
  label: string;
  suffix?: string;
  delay?: number;
}

function StatItem({ value, label, suffix = '', delay = 0 }: StatItemProps) {
  const count = useMotionValue(0);
  const rounded = useTransform(count, (latest) => Math.round(latest));
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          const controls = animate(count, value, {
            duration: 2,
            delay,
          });
          return () => controls.stop();
        }
      },
      { threshold: 0.5 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, [count, value, delay]);

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay }}
      className="text-center"
    >
      <div className="text-5xl md:text-6xl bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent mb-4">
        <motion.span>{rounded}</motion.span>
        {suffix}
      </div>
      <div className="text-white/70 text-lg">{label}</div>
    </motion.div>
  );
}

export function Stats() {
  return (
    <section className="relative py-24 bg-slate-900">
      <div className="absolute inset-0 bg-gradient-to-r from-blue-500/10 to-purple-500/10" />
      
      <div className="relative z-10 max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <StatItem value={500} label="Projects Completed" suffix="+" delay={0} />
          <StatItem value={98} label="Client Satisfaction" suffix="%" delay={0.2} />
          <StatItem value={50} label="Team Members" suffix="+" delay={0.4} />
          <StatItem value={15} label="Years Experience" suffix="+" delay={0.6} />
        </div>
      </div>
    </section>
  );
}
