import { motion } from 'motion/react';
import { useEffect, useState } from 'react';

interface AnimatedShapeProps {
  type: 'cube' | 'sphere' | 'pyramid' | 'torus';
  color: string;
  size: number;
  position: { x: string; y: string };
  delay?: number;
}

export function AnimatedShape({ type, color, size, position, delay = 0 }: AnimatedShapeProps) {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth - 0.5) * 20,
        y: (e.clientY / window.innerHeight - 0.5) * 20,
      });
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const shapeVariants = {
    animate: {
      y: [0, -30, 0],
      rotateX: [0, 360],
      rotateY: [0, 360],
      transition: {
        duration: 8,
        repeat: Infinity,
        ease: 'easeInOut',
        delay,
      },
    },
  };

  const renderShape = () => {
    const baseClasses = 'absolute';
    const style = {
      width: `${size}px`,
      height: `${size}px`,
      background: color,
    };

    switch (type) {
      case 'cube':
        return (
          <div
            className={`${baseClasses} rounded-lg shadow-2xl`}
            style={{
              ...style,
              background: `linear-gradient(135deg, ${color}, ${color}dd)`,
              boxShadow: `0 20px 60px ${color}40`,
            }}
          />
        );
      case 'sphere':
        return (
          <div
            className={`${baseClasses} rounded-full shadow-2xl`}
            style={{
              ...style,
              background: `radial-gradient(circle at 30% 30%, ${color}ff, ${color}80)`,
              boxShadow: `0 20px 60px ${color}40`,
            }}
          />
        );
      case 'pyramid':
        return (
          <div
            className={`${baseClasses} shadow-2xl`}
            style={{
              ...style,
              background: `linear-gradient(135deg, ${color}, ${color}cc)`,
              clipPath: 'polygon(50% 0%, 0% 100%, 100% 100%)',
              boxShadow: `0 20px 60px ${color}40`,
            }}
          />
        );
      case 'torus':
        return (
          <div
            className={`${baseClasses} rounded-full shadow-2xl border-8`}
            style={{
              ...style,
              borderColor: color,
              background: 'transparent',
              boxShadow: `0 20px 60px ${color}40, inset 0 0 30px ${color}30`,
            }}
          />
        );
      default:
        return null;
    }
  };

  return (
    <motion.div
      className="absolute pointer-events-none"
      style={{
        left: position.x,
        top: position.y,
        perspective: '1000px',
        transformStyle: 'preserve-3d',
      }}
      variants={shapeVariants}
      animate="animate"
      initial={{ opacity: 0, scale: 0 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true }}
      transition={{ duration: 0.8 }}
    >
      <motion.div
        style={{
          x: mousePosition.x,
          y: mousePosition.y,
        }}
        transition={{ type: 'spring', stiffness: 50, damping: 20 }}
      >
        {renderShape()}
      </motion.div>
    </motion.div>
  );
}
