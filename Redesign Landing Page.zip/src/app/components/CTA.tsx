import { motion } from 'motion/react';
import { AnimatedShape } from './AnimatedShape';
import { ArrowRight, Mail } from 'lucide-react';

export function CTA() {
  return (
    <section className="relative py-32 bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900 overflow-hidden">
      {/* Animated Shapes */}
      <AnimatedShape
        type="sphere"
        color="#60a5fa"
        size={200}
        position={{ x: '15%', y: '20%' }}
        delay={0}
      />
      <AnimatedShape
        type="cube"
        color="#c084fc"
        size={150}
        position={{ x: '85%', y: '30%' }}
        delay={0.5}
      />
      <AnimatedShape
        type="torus"
        color="#34d399"
        size={180}
        position={{ x: '10%', y: '70%' }}
        delay={1}
      />

      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-5xl md:text-7xl text-white mb-6">
            Ready to Start Your
            <br />
            <span className="bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400 bg-clip-text text-transparent">
              Next Project?
            </span>
          </h2>
          <p className="text-xl text-white/80 mb-12 max-w-2xl mx-auto">
            Let's collaborate to bring your vision to life with cutting-edge technology
            and innovative solutions
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="group px-8 py-4 bg-white text-slate-900 rounded-full hover:shadow-2xl hover:shadow-white/30 transition-all duration-300 flex items-center justify-center gap-2"
            >
              <Mail className="w-5 h-5" />
              Contact Us
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="px-8 py-4 backdrop-blur-sm bg-white/10 border border-white/20 rounded-full text-white hover:bg-white/20 transition-all duration-300"
            >
              View Portfolio
            </motion.button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
